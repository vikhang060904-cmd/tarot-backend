# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\Admin\\develop\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "D:\\git\\python\\api_web_chatbot_phat_giao\\app_web_view" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\Admin\\develop\\flutter"
  "PROJECT_DIR=D:\\git\\python\\api_web_chatbot_phat_giao\\app_web_view"
  "FLUTTER_ROOT=C:\\Users\\Admin\\develop\\flutter"
  "FLUTTER_EPHEMERAL_DIR=D:\\git\\python\\api_web_chatbot_phat_giao\\app_web_view\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=D:\\git\\python\\api_web_chatbot_phat_giao\\app_web_view"
  "FLUTTER_TARGET=D:\\git\\python\\api_web_chatbot_phat_giao\\app_web_view\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuMzguNw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049M2I2MmVmYzJhMw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NzhmYzMwMTJlNA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMC43"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=D:\\git\\python\\api_web_chatbot_phat_giao\\app_web_view\\.dart_tool\\package_config.json"
)
